//
//  TestScrollView.swift
//  BankManagerUIApp
//
//  Created by Hyungmin Lee on 2023/07/22.
//

import UIKit

class TestScrollView: UIScrollView {
    
    
}
