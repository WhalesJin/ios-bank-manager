//
//  ProcessingScrollView.swift
//  BankManagerUIApp
//
//  Created by Hyungmin Lee on 2023/07/22.
//

import UIKit

final class ProcessingScrollView: UIView {
    private let waitingScrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.backgroundColor = .magenta
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        return scrollView
    }()
    
    private let waitingContentView: UIView = {
        let view = UIView()
        view.backgroundColor = .red
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var taskingScrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.backgroundColor = .brown
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.delegate = self
        return scrollView
    }()
    
    private let taskingContentView: UIView = {
        let view = UIView()
        view.backgroundColor = .blue
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private let waitingStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 10
        stackView.distribution = .fillEqually
        stackView.backgroundColor = .white
        stackView.alignment = .center
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    private let taskingStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 10
        stackView.distribution = .fillEqually
        stackView.backgroundColor = .orange
        stackView.alignment = .center
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    convenience init() {
        self.init(frame: CGRect.zero)
        
//        axis = .horizontal
//        distribution = .fillEqually
//        backgroundColor = .gray
        
        configureUI()
        setUpConstraints()
        setUpLabels()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureUI() {
        waitingContentView.addSubview(waitingStackView)
        waitingScrollView.addSubview(waitingContentView)
        taskingContentView.addSubview(taskingStackView)
        taskingScrollView.addSubview(taskingContentView)
        
//        [waitingScrollView, taskingScrollView].forEach { addArrangedSubview($0) }
        [waitingScrollView, taskingScrollView].forEach { addSubview($0) }
    }
    
    private func setUpConstraints() {
        NSLayoutConstraint.activate([
            waitingScrollView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.5),
            waitingScrollView.leadingAnchor.constraint(equalTo: leadingAnchor),
            waitingScrollView.topAnchor.constraint(equalTo: topAnchor),
            waitingScrollView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
        
        NSLayoutConstraint.activate([
//            taskingScrollView.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 0.5),
            taskingScrollView.leadingAnchor.constraint(equalTo: waitingScrollView.trailingAnchor),
            taskingScrollView.trailingAnchor.constraint(equalTo: trailingAnchor),
            taskingScrollView.topAnchor.constraint(equalTo: topAnchor),
            taskingScrollView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
        
//        setUpWaitingContentViewConstraints()
//        setUpTaskingContentViewConstraints()
        setUpContenViewConstraints(waitingContentView, waitingScrollView)
        setUpContenViewConstraints(taskingContentView, taskingScrollView)
        setUpWaitingStackViewConstraints()
        setUpTaskingStackViewConstraints()
    }
    
    private func setUpLabels() {
        for _ in 0...4 {
            let label = UILabel()
            label.text = "TEST"
            
            waitingStackView.addArrangedSubview(label)
        }
        
        for _ in 0...4 {
            let label = UILabel()
            label.text = "TEST"
            
            taskingStackView.addArrangedSubview(label)
        }
    }
    
}

// MARK: - Constraints
extension ProcessingScrollView {
    private func setUpContenViewConstraints(_ contenView: UIView, _ scrollView: UIScrollView) {
        NSLayoutConstraint.activate([
            contenView.leadingAnchor.constraint(equalTo: scrollView.frameLayoutGuide.leadingAnchor),
            contenView.trailingAnchor.constraint(equalTo: scrollView.frameLayoutGuide.trailingAnchor),
            contenView.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),
            contenView.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),
//            contenView.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor)
        ])
        
        let heightConstraint = contenView.heightAnchor.constraint(equalTo: scrollView.frameLayoutGuide.heightAnchor, constant: 1)
        heightConstraint.priority = .init(1)
        heightConstraint.isActive = true
    }
    
    private func setUpWaitingStackViewConstraints() {
        NSLayoutConstraint.activate([
            waitingStackView.leadingAnchor.constraint(equalTo: waitingContentView.leadingAnchor),
            waitingStackView.trailingAnchor.constraint(equalTo: waitingContentView.trailingAnchor),
            waitingStackView.topAnchor.constraint(equalTo: waitingContentView.topAnchor),
            waitingStackView.bottomAnchor.constraint(equalTo: waitingContentView.bottomAnchor)
        ])
    }
    
    private func setUpTaskingStackViewConstraints() {
        NSLayoutConstraint.activate([
            taskingStackView.leadingAnchor.constraint(equalTo: taskingContentView.leadingAnchor),
            taskingStackView.trailingAnchor.constraint(equalTo: taskingContentView.trailingAnchor),
            taskingStackView.topAnchor.constraint(equalTo: taskingContentView.topAnchor),
            taskingStackView.bottomAnchor.constraint(equalTo: taskingContentView.bottomAnchor)
        ])
    }
}

extension ProcessingScrollView: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
//        let value = scrollView.bounds.width == waitingContentView.frame.width
        
        print("\(scrollView.bounds.width), \(waitingContentView.frame.width)")
    }
}
